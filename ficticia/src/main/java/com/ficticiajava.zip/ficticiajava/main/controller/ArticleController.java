package com.ficticiajava.main.controller;

import com.ficticiajava.main.converter.ArticleConverter;
import com.ficticiajava.main.dto.*;
import com.ficticiajava.main.entity.Article;
import com.ficticiajava.main.global.EndPoint;
import com.ficticiajava.main.global.Pagination;
import com.ficticiajava.main.service.ArticleService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Validated
@RestController
@RequestMapping(value = EndPoint.ARTICLE)
public class ArticleController {

    private final ArticleService service;

    public ArticleController(ArticleService service) {
        this.service = service;
    }

    @GetMapping()
    public ResponseEntity<?> findAll(
            @Valid @RequestParam(name = "page", required = false, defaultValue = "1") int nPage
    ) {
        Object nReturn;
        Pageable pb;
        Page<Article> page;
        List<ArticleDto> results;

        try {
            pb = PageRequest.of(nPage - 1, Pagination.PAGE_SIZE);
            page = service.findAll(pb);

            results = page.getContent().stream()
                    .map(ArticleConverter::toDto)
                    .collect(Collectors.toList());

            nReturn = new ResponseResultsDto(
                    HttpStatus.OK,
                    page.getTotalElements(),
                    page.getTotalPages(),
                    page.getNumber() + 1,
                    page.getSize(),
                    results
            );
        } catch (Exception e) {
            return new ResponseEntity<>(
                    new ResponseErrorDto(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), LocalDateTime.now()),
                    null,
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        }

        return new ResponseEntity<>(
                nReturn,
                null,
                HttpStatus.OK
        );
    }

    @GetMapping(params = {"id"})
    public ResponseEntity<?> findById(
            @Valid @RequestParam(name = "id") Long nId
    ) {
        Object nReturn = null;

        if(nId <= 0)
            return new ResponseEntity<>(
                    new ResponseErrorDto(HttpStatus.BAD_REQUEST, "Identificador (ID) no válido", LocalDateTime.now()),
                    null,
                    HttpStatus.BAD_REQUEST
            );

        if(!service.existsById(nId))
            return new ResponseEntity<>(
                    new ResponseErrorDto(HttpStatus.NOT_FOUND, "No existe el elemento en la base de datos.", LocalDateTime.now()),
                    null,
                    HttpStatus.NOT_FOUND
            );

        try { // filtrar por ID
            Optional<Article> aux = service.findById(nId);
            if(aux.isPresent())
                nReturn = ArticleConverter.toDto(aux.orElse(null));
        } catch (Exception e) {
            return new ResponseEntity<>(
                    new ResponseErrorDto(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), LocalDateTime.now()),
                    null,
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        }

        return new ResponseEntity<>(
                nReturn,
                null,
                HttpStatus.OK
        );
    }

    @GetMapping(params = {"q"})
    public ResponseEntity<?> findAllByFullNameContainsIgnoreCase(
            @Valid /*@Size(min = 3, max = 255)*/ @RequestParam(name = "q") String strLike,
            @Valid @RequestParam(name = "page", required = false, defaultValue = "1") int nPage
    ) {
        Object nReturn;
        Pageable pb;
        Page<Article> page;
        List<ArticleDto> results;

        try {
            pb = PageRequest.of(nPage - 1, Pagination.PAGE_SIZE);

            if(strLike.trim().length() >= 3) {// filtrar por strLike
                page = service.findAllByTitleContainsOrDescriptionContainsOrContentContainsOrAuthorFullNameContainsIgnoreCase(strLike, pb);

                results = page.getContent().stream()
                        .map(ArticleConverter::toDto)
                        .collect(Collectors.toList());

                nReturn = new ResponseResultsDto(
                        HttpStatus.OK,
                        page.getTotalElements(),
                        page.getTotalPages(),
                        page.getNumber() + 1,
                        page.getSize(),
                        results
                );
            }
            else
                return new ResponseEntity<>(
                        new ResponseErrorDto(
                                HttpStatus.BAD_REQUEST,
                                strLike.trim().length() == 0 ? "No se puede realizar la consulta con el parámetro Q vacío." : "El texto a buscar es muy corto.",
                                LocalDateTime.now()
                        ),
                        null,
                        HttpStatus.BAD_REQUEST
                );
        } catch (Exception e) {
            return new ResponseEntity<>(
                    new ResponseErrorDto(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), LocalDateTime.now()),
                    null,
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        }

        return new ResponseEntity<>(
                nReturn,
                null,
                HttpStatus.OK
        );
    }

    @PostMapping()
    public ResponseEntity<?> create(
            @Valid @RequestBody ArticleDto n
    ) {
        ArticleDto temporal;

        try {
            temporal = service.createArticle(n);
        } catch (Exception e) {
            return new ResponseEntity<>(
                    new ResponseErrorDto(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), LocalDateTime.now()),
                    null,
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        }

        return new ResponseEntity<>(
                temporal,
                null,
                HttpStatus.CREATED
            );
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(
            @Valid @PathVariable("id") Long nId,
            @Valid @RequestBody ArticleDto n
    ) {
        Object temporal;

        if(!service.existsById(nId))
            return new ResponseEntity<>(
                    new ResponseErrorDto(HttpStatus.NOT_FOUND, "No existe el elemento en la base de datos.", LocalDateTime.now()),
                    null,
                    HttpStatus.NOT_FOUND
            );

        try {
            temporal = service.updateById(nId, n);
        } catch (Exception e) {
            return new ResponseEntity<>(
                    new ResponseErrorDto(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), LocalDateTime.now()),
                    null,
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        }

        return new ResponseEntity<>(
                temporal,
                null,
                HttpStatus.OK
            );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(
            @Valid @PathVariable("id") Long nId
    ) {
        boolean bReturn;

        if(nId <= 0)
            return new ResponseEntity<>(
                    new ResponseErrorDto(HttpStatus.BAD_REQUEST, "Identificador (ID) no válido", LocalDateTime.now()),
                    null,
                    HttpStatus.BAD_REQUEST
            );

        if(!service.existsById(nId))
            return new ResponseEntity<>(
                    new ResponseErrorDto(HttpStatus.NOT_FOUND, "No existe el elemento en la base de datos.", LocalDateTime.now()),
                    null,
                    HttpStatus.NOT_FOUND
            );

        try {
            bReturn = service.deleteById(nId);
        } catch (Exception e) {
            return new ResponseEntity<>(
                    new ResponseErrorDto(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), LocalDateTime.now()),
                    null,
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        }

        return new ResponseEntity<>(
                bReturn ? "DELETED" : "NOT DELETED",
                null,
                HttpStatus.NO_CONTENT
        );
    }
}
package com.ficticiajava.main.runner;

import com.ficticiajava.main.entity.Category;
import com.ficticiajava.main.repository.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Order(3)
public class CategoryRunner implements CommandLineRunner {
    private final CategoryRepository repository;

    @Autowired
    public CategoryRunner(CategoryRepository repository) {
        this.repository = repository;
    }

    @Override
    public void run(String[] args) throws Exception {
        String[] abcd = {
                "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M",
                "Ñ", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"
        };

        for(String c : abcd)
            repository.save(new Category(c));
    }
}
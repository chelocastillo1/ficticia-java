package com.ficticiajava.main.controller;

import com.ficticiajava.main.converter.AuthorConverter;
import com.ficticiajava.main.dto.AuthorDto;
import com.ficticiajava.main.dto.ResponseErrorDto;
import com.ficticiajava.main.dto.ResponseResultsDto;
import com.ficticiajava.main.entity.Author;
import com.ficticiajava.main.global.EndPoint;
import com.ficticiajava.main.global.Pagination;
import com.ficticiajava.main.service.AuthorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping(value = EndPoint.AUTHOR)
public class AuthorController {

    private final AuthorService service;

    @Autowired
    public AuthorController(AuthorService service) {
        this.service = service;
    }

    @GetMapping()
    public ResponseEntity<?> findAll(
            @Valid @RequestParam(name = "page", required = false, defaultValue = "1") int nPage
    ) {
        Object nReturn;
        Pageable pb;
        Page<Author> page;
        List<AuthorDto> results;

        try {
            pb = PageRequest.of(nPage - 1, Pagination.PAGE_SIZE);
            page = service.findAll(pb);

            results = page.getContent().stream()
                    .map(AuthorConverter::toDto)
                    .collect(Collectors.toList());

            nReturn = new ResponseResultsDto(
                    HttpStatus.OK,
                    page.getTotalElements(),
                    page.getTotalPages(),
                    page.getNumber() + 1,
                    page.getSize(),
                    results
            );
        } catch (Exception e) {
            return new ResponseEntity<>(
                    new ResponseErrorDto(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), LocalDateTime.now()),
                    null,
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        }

        return new ResponseEntity<>(
                nReturn,
                null,
                HttpStatus.OK
        );
    }

    @GetMapping(params = {"id"})
    public ResponseEntity<?> findById(
            @Valid @RequestParam(name = "id") Long nId
    ) {
        Object nReturn = null;

        if(nId <= 0)
            return new ResponseEntity<>(
                    new ResponseErrorDto(HttpStatus.BAD_REQUEST, "Identificador (ID) no válido", LocalDateTime.now()),
                    null,
                    HttpStatus.BAD_REQUEST
            );

        if(!service.existsById(nId))
            return new ResponseEntity<>(
                    new ResponseErrorDto(HttpStatus.NOT_FOUND, "No existe el elemento en la base de datos.", LocalDateTime.now()),
                    null,
                    HttpStatus.NOT_FOUND
            );

        try { // filtrar por ID
            Optional<Author> aux = service.findById(nId);
            if(aux.isPresent())
                nReturn = AuthorConverter.toDto(aux.orElse(null));
        } catch (Exception e) {
            return new ResponseEntity<>(
                    new ResponseErrorDto(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), LocalDateTime.now()),
                    null,
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        }

        return new ResponseEntity<>(
                nReturn,
                null,
                HttpStatus.OK
        );
    }

    @GetMapping(params = {"createdAtAfter"})
    public ResponseEntity<?> findByCreatedAtAfter(
            @Valid @RequestParam(name = "createdAtAfter") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dCreatedAtAfter,
            @Valid @RequestParam(name = "page", required = false, defaultValue = "1") int nPage
    ) {
        Object nReturn;
        Pageable pb;
        Page<Author> page;
        List<AuthorDto> results;

        try {
            pb = PageRequest.of(nPage - 1, Pagination.PAGE_SIZE);

            if(dCreatedAtAfter != null) {// filtrar por CreatedAtAfter
                page = service.findByCreatedAtAfter(dCreatedAtAfter, pb);

                results = page.getContent().stream()
                        .map(AuthorConverter::toDto)
                        .collect(Collectors.toList());

                nReturn = new ResponseResultsDto(
                        HttpStatus.OK,
                        page.getTotalElements(),
                        page.getTotalPages(),
                        page.getNumber() + 1,
                        page.getSize(),
                        results
                );
            }
            else
                return new ResponseEntity<>(
                        new ResponseErrorDto(HttpStatus.BAD_REQUEST, "No se puede realizar la consulta con el parámetro CREATEDAT vacío.", LocalDateTime.now()),
                        null,
                        HttpStatus.BAD_REQUEST
                );
        } catch (Exception e) {
            return new ResponseEntity<>(
                    new ResponseErrorDto(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), LocalDateTime.now()),
                    null,
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        }

        return new ResponseEntity<>(
                nReturn,
                null,
                HttpStatus.OK
        );
    }

    @GetMapping(params = {"fullName"})
    public ResponseEntity<?> findAllByFullNameContainsIgnoreCase(
            @Valid @RequestParam(name = "fullName", defaultValue = "") String strFullName,
            @Valid @RequestParam(name = "page", required = false, defaultValue = "1") int nPage
    ) {
        Object nReturn;
        Pageable pb;
        Page<Author> page;
        List<AuthorDto> results;

        try {
            pb = PageRequest.of(nPage - 1, Pagination.PAGE_SIZE);

            if(strFullName.trim().length() > 0) {// filtrar por FullName
                page = service.findAllByFullNameContainsIgnoreCase(strFullName, pb);

                results = page.getContent().stream()
                        .map(AuthorConverter::toDto)
                        .collect(Collectors.toList());

                nReturn = new ResponseResultsDto(
                        HttpStatus.OK,
                        page.getTotalElements(),
                        page.getTotalPages(),
                        page.getNumber() + 1,
                        page.getSize(),
                        results
                );
            }
            else
                return new ResponseEntity<>(
                        new ResponseErrorDto(HttpStatus.BAD_REQUEST, "No se puede realizar la consulta con el parámetro NAME vacío.", LocalDateTime.now()),
                        null,
                        HttpStatus.BAD_REQUEST
                );
        } catch (Exception e) {
            return new ResponseEntity<>(
                    new ResponseErrorDto(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), LocalDateTime.now()),
                    null,
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        }

        return new ResponseEntity<>(
                nReturn,
                null,
                HttpStatus.OK
        );
    }

    @PostMapping()
    public ResponseEntity<?> create(
            @Valid @RequestBody AuthorDto n
    ) {
        Object temporal;

        try {
            temporal = service.createAuthor(n);
        } catch (Exception e) {
        return new ResponseEntity<>(
                new ResponseErrorDto(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), LocalDateTime.now()),
                null,
                HttpStatus.INTERNAL_SERVER_ERROR
            );
        }

        return new ResponseEntity<>(
                temporal,
                null,
                HttpStatus.CREATED
            );
    }

    @PutMapping("{id}")
    public ResponseEntity<?> update(
            @Valid @PathVariable("id") Long nId,
            @Valid @RequestBody AuthorDto n
    ) {
        Object temporal;

        if(!service.existsById(nId))
            return new ResponseEntity<>(
                    new ResponseErrorDto(HttpStatus.NOT_FOUND, "No existe el elemento en la base de datos.", LocalDateTime.now()),
                    null,
                    HttpStatus.NOT_FOUND
            );

        try {
            temporal = service.updateById(nId, n);
        } catch (Exception e) {
            return new ResponseEntity<>(
                    new ResponseErrorDto(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), LocalDateTime.now()),
                    null,
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        }

        return new ResponseEntity<>(
                temporal,
                null,
                HttpStatus.OK
            );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(
            @Valid @PathVariable("id") Long nId
    ) {
        boolean bReturn;

        if(nId <= 0)
            return new ResponseEntity<>(
                    new ResponseErrorDto(HttpStatus.BAD_REQUEST, "Identificador (ID) no válido", LocalDateTime.now()),
                    null,
                    HttpStatus.BAD_REQUEST
            );

        if(!service.existsById(nId))
            return new ResponseEntity<>(
                    new ResponseErrorDto(HttpStatus.BAD_REQUEST, "No existe el elemento en la base de datos.", LocalDateTime.now()),
                    null,
                    HttpStatus.BAD_REQUEST
            );

        try {
            bReturn = service.deleteById(nId);
        } catch (Exception e) {
            return new ResponseEntity<>(
                    new ResponseErrorDto(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), LocalDateTime.now()),
                    null,
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        }

        return new ResponseEntity<>(
                bReturn ? "DELETED" : "NOT DELETED",
                null,
                HttpStatus.NO_CONTENT
        );
    }
}
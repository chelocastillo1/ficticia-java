package com.ficticiajava.main.dto;

import javax.validation.constraints.NotBlank;

public final class CategoryDto extends GenericDto {

    @NotBlank
    private final String name;

    public CategoryDto(Long id, String name) {
        super(id);
        this.name = name;
    }

    public String getName() {
        return name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CategoryDto)) return false;

        CategoryDto that = (CategoryDto) o;

        return name.equals(that.name);
    }

    @Override
    public int hashCode() {
        return name.hashCode();
    }

    @Override
    public String toString() {
        return "CategoryDto{" +
                "name='" + name + '\'' +
                '}';
    }
}
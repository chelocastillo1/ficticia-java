package com.ficticiajava.main.runner;

import com.ficticiajava.main.entity.Author;
import com.ficticiajava.main.repository.AuthorRepository;
import com.ficticiajava.main.repository.SourceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Component
@Order(2)
public class AuthorRunner implements CommandLineRunner {

    private final AuthorRepository rAuthor;
    //private final SourceRepository rSource;

    @Autowired
    public AuthorRunner(AuthorRepository rAuthor/*, SourceRepository rSource*/) {
        this.rAuthor = rAuthor;
        //this.rSource = rSource;
    }

    @Override
    public void run(String[] args) throws Exception {
        Author[] lista = {
                new Author("Marcelo", "Castillo", LocalDate.of(1985, 8, 25)/*, rSource.getReferenceById(1L)*/),
                new Author("Gonzalo", "Castillo", LocalDate.of(1992, 12, 10)/*, rSource.getReferenceById(2L)*/),
                new Author("Hugo", "Castillo", LocalDate.of(1958, 1, 20)/*, rSource.getReferenceById(3L)*/),
                new Author("Liliana", "Lemaire", LocalDate.of(1963, 2, 8)/*, rSource.getReferenceById(2L)*/)
        };

        for(Author n : lista)
            rAuthor.save(n);
    }
}
package com.ficticiajava.main.service;

import com.ficticiajava.main.converter.ArticleConverter;
import com.ficticiajava.main.dto.ArticleDto;
import com.ficticiajava.main.entity.Article;
import com.ficticiajava.main.entity.Category;
import com.ficticiajava.main.repository.ArticleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class ArticleService {

    private final ArticleRepository repository;

    @Autowired
    public ArticleService(ArticleRepository repository) {
        this.repository = repository;
    }

    public boolean existsById(Long nId) {
        return repository.existsById(nId);
    }

    public Optional<Article> findById(Long nId) {
        return repository.findById(nId);
    }

    public List<Article> findAll() {
        return repository.findAll();
    }

    public Page<Article> findAll(Pageable pb) {
        return repository.findAll(pb);
    }

    public List<Article> findAllByTitleContainsOrDescriptionContainsOrContentContainsOrAuthorFullNameContainsIgnoreCase(String strLike) {
        return repository.findAllByTitleContainsOrDescriptionContainsOrContentContainsOrAuthorFullNameContainsIgnoreCase(strLike, strLike, strLike, strLike);
    }

    public Page<Article> findAllByTitleContainsOrDescriptionContainsOrContentContainsOrAuthorFullNameContainsIgnoreCase(String strLike, Pageable pb) {
        return repository.findAllByTitleContainsOrDescriptionContainsOrContentContainsOrAuthorFullNameContainsIgnoreCase(strLike, strLike, strLike, strLike, pb);
    }

    public Article createArticle(Article n) {
        return repository.save(n);
    }

    public ArticleDto createArticle(ArticleDto n) {
        Article temp = ArticleConverter.toEntity(n);

        // Blanqueamos las relaciones y solo registramos los demás atributos.
        temp.setAuthor(null);
        temp.setSource(null);
        temp.setCategories(new ArrayList<>());

        return ArticleConverter.toDto(
                this.createArticle(temp)
        );
    }

    public ArticleDto updateById(Long nId, ArticleDto n) {
        return ArticleConverter.toDto(
                this.updateById(nId, ArticleConverter.toEntity(n))
        );
    }

    public Article updateById(Long nId, Article n) {
        Article nExistente;

        nExistente = repository.findById(nId).orElse(null);

        if(nExistente != null) {
            if (nExistente.getTitle().compareToIgnoreCase(n.getTitle()) != 0)
                nExistente.setTitle(n.getTitle());

            if (nExistente.getDescription().compareToIgnoreCase(n.getDescription()) != 0)
                nExistente.setDescription(n.getDescription());

            if (nExistente.getUrl().compareToIgnoreCase(n.getUrl()) != 0)
                nExistente.setUrl(n.getUrl());

            if (nExistente.getUrlToImage().compareToIgnoreCase(n.getUrlToImage()) != 0)
                nExistente.setUrlToImage(n.getUrlToImage());

            if (!nExistente.getPublishedAt().isEqual(n.getPublishedAt()))
                nExistente.setPublishedAt(n.getPublishedAt());

            if (nExistente.getContent().compareToIgnoreCase(n.getContent()) != 0)
                nExistente.setContent(n.getContent());

            return repository.save(nExistente);
        }

        return null;
    }

    public boolean deleteById(Long nId) {
        Article nExistente;

        nExistente = repository.findById(nId).orElse(null);

        if(nExistente != null) {
            nExistente.getAuthor().removeArticle(nExistente);
            nExistente.getSource().removeArticle(nExistente);

            for(Category c : nExistente.getCategories())
                c.removeArticle(nExistente);

            repository.deleteById(nId);
            return !repository.existsById(nId);
        }

        return false;
    }
}
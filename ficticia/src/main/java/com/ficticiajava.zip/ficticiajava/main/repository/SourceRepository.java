package com.ficticiajava.main.repository;

import com.ficticiajava.main.entity.Category;
import com.ficticiajava.main.entity.Source;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface SourceRepository extends JpaRepository<Source, Long>, PagingAndSortingRepository<Source, Long> {
    List<Source> findAllByNameContainsIgnoreCase(String name);
    Page<Source> findAllByNameContainsIgnoreCase(String name, Pageable pb);

    List<Source> findAllByCreatedAtAfter(LocalDate createdAt);
    Page<Source> findAllByCreatedAtAfter(LocalDate createdAt, Pageable pb);
}
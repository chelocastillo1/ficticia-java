package com.ficticiajava.main.dto;

import org.springframework.http.HttpStatus;

public final class ResponseResultsDto extends GenericResponseDto {
    private final Long totalResults;
    private final Integer totalPages;
    private final Integer page;
    private final Integer pageSize;
    private final Object data;

    public ResponseResultsDto(HttpStatus status, Long totalResults, Integer totalPages, Integer page, Integer pageSize, Object data) {
        super(status);
        this.totalResults = totalResults;
        this.totalPages = totalPages;
        this.page = page;
        this.pageSize = pageSize;
        this.data = data;
    }

    /**
     * Retorna el total de elementos encontrados.
     **/
    public Long getTotalResults() {
        return totalResults;
    }

    /**
     * Devuelve el total de páginas calculadas.
     **/
    public Integer getTotalPages() {
        return totalPages;
    }

    /**
     * Devuelve el número de página actual que se está visualizando.
     **/
    public Integer getPage() {
        return page;
    }

    /**
     * Devuelve un entero que representa la cantidad de elementos mostrados por página.
     **/
    public Integer getPageSize() {
        return pageSize;
    }

    /**
     * Devuelve un List que contiene los resultados obtenidos de la consulta.
     **/
    public Object getData() {
        return data;
    }
}
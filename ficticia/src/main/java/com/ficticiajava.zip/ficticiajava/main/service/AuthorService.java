package com.ficticiajava.main.service;

import com.ficticiajava.main.converter.AuthorConverter;
import com.ficticiajava.main.dto.AuthorDto;
import com.ficticiajava.main.entity.Article;
import com.ficticiajava.main.entity.Author;
import com.ficticiajava.main.repository.AuthorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class AuthorService {

    private final AuthorRepository repository;

    @Autowired
    public AuthorService(AuthorRepository repository) {
        this.repository = repository;
    }

    public boolean existsById(Long nId) {
        return repository.existsById(nId);
    }

    public List<Author> findAll() {
        return repository.findAll();
    }

    public Page<Author> findAll(Pageable pb) {
        return repository.findAll(pb);
    }

    public List<Author> findAllByFullNameContainsIgnoreCase(String strFullNameContains) {
        return repository.findAllByFullNameContainsIgnoreCase(strFullNameContains);
    }

    public Page<Author> findAllByFullNameContainsIgnoreCase(String strFullNameContains, Pageable pb) {
        return repository.findAllByFullNameContainsIgnoreCase(strFullNameContains, pb);
    }

    public List<Author> findByCreatedAtAfter(LocalDate dCreatedAt) {
        return repository.findAllByCreatedAtAfter(dCreatedAt);
    }

    public Page<Author> findByCreatedAtAfter(LocalDate dCreatedAt, Pageable pb) {
        return repository.findAllByCreatedAtAfter(dCreatedAt, pb);
    }

    public Optional<Author> findById(Long nId) {
        return repository.findById(nId);
    }

    public Author createAuthor(Author n) {
        return repository.save(n);
    }

    public AuthorDto createAuthor(AuthorDto n) {
        return AuthorConverter.toDto(
                this.createAuthor(AuthorConverter.toEntity(n))
        );
    }

    public AuthorDto updateById(Long nId, AuthorDto n) {
        return AuthorConverter.toDto(
                this.updateById(nId, AuthorConverter.toEntity(n))
        );
    }

    public Author updateById(Long nId, Author n) {
        Author nExistente;

        nExistente = repository.findById(nId).orElse(null);

        if(nExistente != null) {
            if (nExistente.getFirstName().compareToIgnoreCase(n.getFirstName()) != 0)
                nExistente.setFirstName(n.getFirstName());

            if (nExistente.getLastName().compareToIgnoreCase(n.getLastName()) != 0)
                nExistente.setLastName(n.getLastName());

            if (!nExistente.getCreatedAt().isEqual(n.getCreatedAt()))
                nExistente.setCreatedAt(n.getCreatedAt());

            return repository.save(nExistente);
        }

        return null;
    }

    public boolean deleteById(Long nId) {
        Author nExistente;

        nExistente = repository.findById(nId).orElse(null);

        if(nExistente != null) {
            for(Article a : nExistente.getArticles()) {
                a.getAuthor().removeArticle(a);
                //a.setAuthor(null);
            }

            repository.deleteById(nId);
            return !repository.existsById(nId);
        }

        return false;
    }
}
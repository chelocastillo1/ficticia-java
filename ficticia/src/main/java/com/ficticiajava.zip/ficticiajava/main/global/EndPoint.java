package com.ficticiajava.main.global;

public final class EndPoint {
    private static final String BASE = "/api/v1/";
    public static final String ARTICLE = BASE + "article";
    public static final String AUTHOR = BASE + "author";
    public static final String CATEGORY = BASE + "category";
    public static final String SOURCE = BASE + "source";
}
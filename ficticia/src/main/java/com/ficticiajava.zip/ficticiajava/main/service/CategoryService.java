package com.ficticiajava.main.service;

import com.ficticiajava.main.entity.Article;
import com.ficticiajava.main.entity.Category;
import com.ficticiajava.main.repository.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CategoryService {

    private final CategoryRepository repository;

    @Autowired
    public CategoryService(CategoryRepository repository) {
        this.repository = repository;
    }

    public boolean existsById(Long nId) {
        return repository.existsById(nId);
    }

    public List<Category> findAll() {
        return repository.findAll();
    }

    public Page<Category> findAll(Pageable pb) {
        return repository.findAll(pb);
    }

    public Optional<Category> findById(Long nId) {
        return repository.findById(nId);
    }

    public List<Category> findAllByNameContainsIgnoreCase(String strNameContains) {
        return repository.findAllByNameContainsIgnoreCase(strNameContains);
    }

    public Page<Category> findAllByNameContainsIgnoreCase(String strNameContains, Pageable pb) {
        return repository.findAllByNameContainsIgnoreCase(strNameContains, pb);
    }

    public Category createCategory(Category n) {
        return repository.save(n);
    }

    public Category updateById(Long nId, Category n) {
        Category nExistente;

        nExistente = repository.findById(nId).orElse(null);

        if(nExistente != null) {
            if (nExistente.getName().compareToIgnoreCase(n.getName()) != 0)
                nExistente.setName(n.getName());

            return repository.save(nExistente);
        }

        return null;
    }

    public boolean deleteById(Long nId) {
        Category nExistente;

        nExistente = repository.findById(nId).orElse(null);

        if(nExistente != null) {
            for(Article a : nExistente.getArticles())
                a.getCategories().clear();

            nExistente.getArticles().clear();
            repository.deleteById(nId);
            return !repository.existsById(nId);
        }

        return false;
    }
}
package com.ficticiajava.main.converter;

import com.ficticiajava.main.dto.ArticleDto;
import com.ficticiajava.main.entity.Article;
import org.springframework.stereotype.Component;

import java.util.ArrayList;

@Component
public final class ArticleConverter {

    /**
     * Permite mapear de objeto DTO a ENTITY.
     * @param dto Objeto DTO a convertir.
     * @return Devuelve el objeto ENTITY convertido.
     **/
    public static Article toEntity(ArticleDto dto) {
        return new Article(
                dto.getId(),
                dto.getTitle(),
                dto.getDescription(),
                dto.getUrl(),
                dto.getUrlToImage(),
                dto.getPublishedAt(),
                dto.getContent(),
                AuthorConverter.toEntity(dto.getAuthor()),
                null,
                new ArrayList<>()
        );
    }

//    AuthorConverter.toEntity(dto.getAuthor()),
//            SourceConverter.toEntity(dto.getSource()),
//            CategoryConverter.toEntity(dto.getCategories())

    /**
     * Permite mapear de objeto ENTITY a DTO.
     * @param e Objeto ENTITY a convertir.
     * @return Devuelve el objeto ArticleDto convertido.
     **/
    public static ArticleDto toDto(Article e) {
        return new ArticleDto(
                e.getId(),
                e.getTitle(),
                e.getDescription(),
                e.getUrl(),
                e.getUrlToImage(),
                e.getPublishedAt(),
                e.getContent(),
                e.getAuthor() != null ? AuthorConverter.toDto(e.getAuthor()) : null,
                e.getSource() != null ? SourceConverter.toDto(e.getSource()) : null,
                e.getCategories().size() > 0 ? CategoryConverter.toDto(e.getCategories()) : new ArrayList<>()
        );
    }
}
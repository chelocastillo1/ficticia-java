package com.ficticiajava.main.service;

import com.ficticiajava.main.converter.SourceConverter;
import com.ficticiajava.main.dto.SourceDto;
import com.ficticiajava.main.entity.Article;
import com.ficticiajava.main.entity.Source;
import com.ficticiajava.main.repository.SourceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class SourceService {

    private final SourceRepository repository;

    @Autowired
    public SourceService(SourceRepository repository) {
        this.repository = repository;
    }

    public boolean existsById(Long nId) {
        return repository.existsById(nId);
    }

    public List<Source> findAll() {
        return repository.findAll();
    }

    public Page<Source> findAll(Pageable pb) {
        return repository.findAll(pb);
    }

    public List<Source> findAllByNameContainsIgnoreCase(String strNameContains) {
        return repository.findAllByNameContainsIgnoreCase(strNameContains);
    }

    public Page<Source> findAllByNameContainsIgnoreCase(String strNameContains, Pageable pb) {
        return repository.findAllByNameContainsIgnoreCase(strNameContains, pb);
    }

    public List<Source> findByCreatedAtAfter(LocalDate dCreatedAt) {
        return repository.findAllByCreatedAtAfter(dCreatedAt);
    }

    public Page<Source> findByCreatedAtAfter(LocalDate dCreatedAt, Pageable pb) {
        return repository.findAllByCreatedAtAfter(dCreatedAt, pb);
    }

    public Optional<Source> findById(Long nId) {
        return repository.findById(nId);
    }

    public Source createSource(Source n) {
        return repository.save(n);
    }

    public SourceDto createSource(SourceDto n) {
        return SourceConverter.toDto(
                this.createSource(SourceConverter.toEntity(n))
        );
    }

    public SourceDto updateById(Long nId, SourceDto n) {
        return SourceConverter.toDto(
                this.updateById(nId, SourceConverter.toEntity(n))
        );
    }

    public Source updateById(Long nId, Source n) {
        Source nExistente;

        nExistente = repository.findById(nId).orElse(null);

        if(nExistente != null) {
            if (nExistente.getName().compareToIgnoreCase(n.getName()) != 0)
                nExistente.setName(n.getName());

            if (nExistente.getCode().compareToIgnoreCase(n.getCode()) != 0)
                nExistente.setCode(n.getCode());

            if (nExistente.getContenido().compareToIgnoreCase(n.getContenido()) != 0)
                nExistente.setContenido(n.getContenido());

            if (!nExistente.getCreatedAt().isEqual(n.getCreatedAt()))
                nExistente.setCreatedAt(n.getCreatedAt());

            return repository.save(nExistente);
        }

        return null;
    }

    public boolean deleteById(Long nId) {
        Source nExistente;

        nExistente = repository.findById(nId).orElse(null);

        if(nExistente != null) {
            for(Article a : nExistente.getArticles())
                a.getSource().removeArticle(a);

            repository.deleteById(nId);
            return !repository.existsById(nId);
        }

        return false;
    }
}
package com.ficticiajava.main.runner;

import com.ficticiajava.main.entity.Article;
import com.ficticiajava.main.entity.Category;
import com.ficticiajava.main.repository.ArticleRepository;
import com.ficticiajava.main.repository.AuthorRepository;
import com.ficticiajava.main.repository.CategoryRepository;
import com.ficticiajava.main.repository.SourceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Component
@Order(4)
public class ArticleRunner implements CommandLineRunner {
    private final ArticleRepository rArticle;
    private final AuthorRepository rAuthor;
    private final CategoryRepository rCategory;
    private final SourceRepository rSource;

    @Autowired
    public ArticleRunner(ArticleRepository rArticle, AuthorRepository rAuthor, CategoryRepository rCategory, SourceRepository rSource) {
        this.rArticle = rArticle;
        this.rAuthor = rAuthor;
        this.rCategory = rCategory;
        this.rSource = rSource;
    }

    @Override
    public void run(String[] args) throws Exception {
        Article[] listaArticulos = {
                new Article(
                        "ABC",
                        "DEF",
                        "http://www.ficticia.com/",
                        "http://www.ficticia.com/images/img01.jpg",
                        LocalDateTime.of(2022, 5, 5, 10, 20, 30),
                        "GHI",
                        rAuthor.findById(1L).orElse(null),
                        rSource.findById(4L).orElse(null)
                ),
                new Article(
                        "JKL",
                        "MNÑ",
                        "http://www.ficticia.com/",
                        "http://www.ficticia.com/images/img01.jpg",
                        LocalDateTime.of(2022, 6, 6, 9,15,3),
                        "OPQ",
                        rAuthor.findById(4L).orElse(null),
                        rSource.findById(3L).orElse(null)
                ),
                new Article(
                        "RST",
                        "UVW",
                        "http://www.ficticia.com/",
                        "http://www.ficticia.com/images/img01.jpg",
                        LocalDateTime.of(2022, 7, 7,22,11,1),
                        "XYZ",
                        rAuthor.findById(2L).orElse(null),
                        rSource.findById(1L).orElse(null)
                ),
                new Article(
                        "QWERTY",
                        "KJH",
                        "http://www.ficticia.com/",
                        "http://www.ficticia.com/images/img01.jpg",
                        LocalDateTime.of(2022, 8, 8,16,9,3),
                        "POI",
                        rAuthor.findById(3L).orElse(null),
                        rSource.findById(2L).orElse(null)
                ),
        };

        Category[][] listaCategorias = {
                {rCategory.findById(1L).get(), rCategory.findById(2L).get()},
                {rCategory.findById(3L).get(), rCategory.findById(4L).get(), rCategory.findById(5L).get()},
                {rCategory.findById(1L).get(), rCategory.findById(3L).get(), rCategory.findById(4L).get(), rCategory.findById(6L).get()},
                {rCategory.findById(2L).get(), rCategory.findById(4L).get(), rCategory.findById(6L).get()},
        };

        for(int i = 0; i < listaArticulos.length ; i++) {
            for(Category c : listaCategorias[i])
                listaArticulos[i].addCategory(c);

            rArticle.save(listaArticulos[i]);
        }

    }
}
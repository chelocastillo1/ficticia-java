package com.ficticiajava.main.entity;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "category")
public final class Category extends GenericEntity {

    @Column(name = "name", length = 50, nullable = false, unique = true)
    private String name;

    @ManyToMany(mappedBy = "categories", fetch = FetchType.EAGER)
    private List<Article> articles = new ArrayList<>(); /* Un ARTICLE puede abarcar más de una CATEGORY */

    public Category() { // default
        super();
    }

    public Category(String name) {
        super();
        this.name = name;
    }

    public Category(Long nId, String name) {
        super(nId);
        this.name = name;
    }

    public void addArticle(Article n) {
        if(!this.articles.contains(n)) {
            this.articles.add(n);
            n.getCategories().add(this);
        }
    }

    public boolean removeArticle(Article n) {
        if(this.articles.contains(n)) {
            this.articles.remove(n);
            n.getCategories().remove(this);
            return this.articles.contains(n);
        }

        return true;
    }

//    public boolean removeAllArticles() {
//        if(this.articles.size() > 0)
//            for(Article a : this.articles) {
//                this.articles.remove(a.getId());
//                a.getCategories().remove(this.getId());
//            }
//
//        return true;
//    }

    public List<Article> getArticles() {
        return articles;
    }

    public void setArticles(List<Article> articles) {
        this.articles = articles;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Category)) return false;

        Category category = (Category) o;

        return name.equals(category.name);
    }

    @Override
    public int hashCode() {
        return name.hashCode();
    }

    @Override
    public String toString() {
        return "Category{" +
                "name='" + name + '\'' +
                '}';
    }
}
package com.ficticiajava.main.repository;

import com.ficticiajava.main.entity.Article;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ArticleRepository extends JpaRepository<Article, Long>, PagingAndSortingRepository<Article, Long> {
    List<Article> findAllByTitleContainsOrDescriptionContainsOrContentContainsOrAuthorFullNameContainsIgnoreCase(String title, String description, String content, String fullName);
    Page<Article> findAllByTitleContainsOrDescriptionContainsOrContentContainsOrAuthorFullNameContainsIgnoreCase(String title, String description, String content, String fullName, Pageable pb);
}
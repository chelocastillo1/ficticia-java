package com.ficticiajava.main.converter;

import com.ficticiajava.main.dto.CategoryDto;
import com.ficticiajava.main.entity.Category;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public final class CategoryConverter {
    /**
     * Permite mapear de objeto DTO a ENTITY.
     * @param dto Objeto DTO a convertir.
     * @return Devuelve el objeto ENTITY convertido.
     **/
    public static Category toEntity(CategoryDto dto) {
        return new Category(
                dto.getId(),
                dto.getName()
        );
    }

    /**
     * Permite mapear una lista de objetos DTO a ENTITY.
     * @param listDtos Lista de objetos DTO a convertir.
     * @return Devuelve una lista de objetos ENTITY convertidos.
     **/
    public static List<Category> toEntity(List<CategoryDto> listDtos) {
        List<Category> listAuxiliar = new ArrayList<>();

        for(CategoryDto c : listDtos)
            listAuxiliar.add(CategoryConverter.toEntity(c));

        return listAuxiliar;
    }

    /**
     * Permite mapear de objeto ENTITY a DTO.
     * @param e Objeto ENTITY a convertir.
     * @return Devuelve el objeto DTO convertido.
     **/
    public static CategoryDto toDto(Category e) {
        return new CategoryDto(
                e.getId(),
                e.getName()
        );
    }

    /**
     * Permite mapear una lista de objetos ENTITY a DTO.
     * @param listEntities Lista de objetos ENTITY a convertir.
     * @return Devuelve una lista de objetos DTO convertidos.
     **/
    public static List<CategoryDto> toDto(List<Category> listEntities) {
        List<CategoryDto> listAuxiliar = new ArrayList<>();

        for(Category c : listEntities)
            listAuxiliar.add(CategoryConverter.toDto(c));

        return listAuxiliar;
    }
}
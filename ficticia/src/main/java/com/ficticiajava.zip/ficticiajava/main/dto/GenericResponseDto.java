package com.ficticiajava.main.dto;

import org.springframework.http.HttpStatus;

import javax.persistence.MappedSuperclass;

@MappedSuperclass
abstract class GenericResponseDto {
    private final HttpStatus status;

    public GenericResponseDto(HttpStatus status) {
        this.status = status;
    }

    public HttpStatus getStatus() {
        return status;
    }
}
